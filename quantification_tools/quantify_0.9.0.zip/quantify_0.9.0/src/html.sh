#!/bin/bash

## get latest quantifier log file
if [[ ! -f "quantifier_$1.log" ]];then
	llog=$(ls -t -c1 quantifier*.log |head -n1)
else
	llog=quantifier_$1.log
	shift
fi

a=$(grep html3 $llog)
echo -e $a
echo adding options $*
$a $*
