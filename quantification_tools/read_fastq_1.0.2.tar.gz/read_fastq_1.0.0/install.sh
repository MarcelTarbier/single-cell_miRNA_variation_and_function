#!/bin/bash


if [[ $1 ]];then
	cd src
	make $1
	cd ..
	exit
fi



cd src
make all
cd ..
ln -s src/read_fastq .
ln -s src/read_fastq_buffered .
a=$(pwd)
if [ `uname` == "Linux" ];then
	sed -i '/read_fastq_1/d' ~/.bash_profile
else
	sed -i "" '/read_fastq_1/ d' ~/.bash_profile
fi

echo "export PATH=$a:\$PATH" >> ~/.bash_profile
