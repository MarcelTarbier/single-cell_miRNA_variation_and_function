void preBmBc(char *x, int m, int bmBc[]);
void preBmGs(char *x, int m, int bmGs[]);
char *BM(char *db, char *pattern,int j, int patternlen,int dblen,int *bmBc,int* bmGs);

