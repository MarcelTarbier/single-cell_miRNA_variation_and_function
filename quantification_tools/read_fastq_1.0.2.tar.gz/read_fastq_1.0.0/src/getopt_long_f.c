#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>

/* Flag set by ‘--verbose’. */
static int verbose_flag;

int getopts(int argc,char *argv[],char *infile,char *pref,char *adap,int *adapl,int *trim,int *clip5p,int *ul,int *entropyu,int *qualu,int *collapseu,int *adapu,int *min_len,int *sout){
	char tmp[10];
	int c;
	while (1) {
		static struct option long_options[] =
		{
			/* These options set a flag. */
			{"verbose", no_argument,       &verbose_flag, 1},
			{"brief",   no_argument,       &verbose_flag, 0},
			/* These options don’t set a flag.
			   We distinguish them by their indices. */
			{"infile", required_argument,       0, 'f'},
			{"outfile",  required_argument,       0, 'o'},
			{"adapter",  required_argument, 0, 'a'},
			{"adapter-len",  required_argument, 0, 'b'},
			{"trim",  required_argument, 0, 't'},
			{"clip5p",    required_argument, 0, 'p'},
			{"umilen",    required_argument, 0, 'u'},
			{"entropy",    no_argument, 0, 'e'},
			{"qual-val",    no_argument, 0, 'q'},
			{"stdout",    no_argument, 0, 's'},
			{"min-len", required_argument,0,'m'},
			{"collapse",    no_argument, 0, 'c'},
			{0, 0, 0, 0}
		};
		/* getopt_long stores the option index here. */
		int option_index = 0;

		c = getopt_long (argc, argv, "f:o:a:b:t:p:u:eqczm:s", long_options, &option_index);

		/* Detect the end of the options. */
		if (c == -1)
			break;

		switch (c) {
			case 0:
				/* If this option set a flag, do nothing else now. */
				if (long_options[option_index].flag != 0)
					break;
				printf ("option %s", long_options[option_index].name);
				if (optarg)
					printf (" with arg %s", optarg);
				printf ("\n");
				break;

			case 'f':
				/*printf("option -f with value `%s'\n",optarg);*/
				sprintf(infile,"%s",optarg);
				break;
			case 'o':
				/*printf("option -o with value `%s'\n",optarg);*/
				sprintf(pref,"%s",optarg);
				break;
			case 'a':
				/*printf("option -a with value `%s'\n",optarg);*/
				sprintf(adap,"%s",optarg);
				*adapu=1; /* set to one if usage is wanted*/
				break;

			case 'b':
				/*printf("option -b with value `%s'\n",optarg);*/
				sprintf(tmp,"%s",optarg);
				*adapl=atoi(tmp);
				break;
			case 'm':
				/*printf("option -b with value `%s'\n",optarg);*/
				sprintf(tmp,"%s",optarg);
				*min_len=atoi(tmp);
				break;
			case 't':
				/*printf("option -t with value `%s'\n",optarg);*/
				sprintf(tmp,"%s",optarg);
				*trim=(int)tmp[0];
				memset(tmp,0,10);
				break;
			case 'p':
				/*printf("option -p with value `%s'\n",optarg);*/
				sprintf(tmp,"%s",optarg);
				*clip5p=atoi(tmp);
				memset(tmp,0,10);
				break;
			case 'u':
				/*printf("option -u with value `%s'\n",optarg);*/
				sprintf(tmp,"%s",optarg);
				*ul=atoi(tmp);
				memset(tmp,0,10);
				break;
			case 'e':
				*entropyu=1;
				/*puts ("option -e\n");*/
				break;
			case 's':
				*sout=1;
				/*puts ("option -e\n");*/
				break;
			case 'q':
				*qualu=1;
				/*puts ("option -q\n");*/
				break;

			case 'c':
				*collapseu=1;
				/*puts ("option -c\n");*/
				break;
			case 'z':
				*adapu=1;
				/*puts ("option -z\n");*/
				break;

			case '?':
				/* getopt_long already printed an error message. */
				break;

			default:
				abort ();
		}
	}
	/* Instead of reporting ‘--verbose’
	   and ‘--brief’ as they are encountered,
	   we report the final status resulting from them. */
	if (verbose_flag)
		fprintf (stderr,"verbose flag is set");

	/* Print any remaining command line arguments (not options). */
	if (optind < argc) {
		fprintf (stderr,"non-option ARGV-elements: ");
		while (optind < argc)
			fprintf (stderr,"%s ", argv[optind++]);
		fprintf (stderr,"\n");
	}
	return 0;
}
