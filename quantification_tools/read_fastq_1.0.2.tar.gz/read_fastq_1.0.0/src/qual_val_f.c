#include <stdio.h>
#include <string.h>

double res[2];

int get_qual(char *quals, double *res,int t){

	int i;
	int val=0;
	double sum=0.0;
	int al=0;
	res[0]=0.0;
	res[1]=0.0;

	for(i=0;i<strlen(quals);i++){
		val=quals[i]-t;
		sum+=val;
		if(val < 30) al++;
	}
	res[0]=sum/i;
	res[1]=al;
	return 0;
}


