#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include<errno.h>

#include <unistd.h>
#include <ctype.h>
#include "getopt_long_f.h"
#include <fcntl.h>

#include <regex.h>
#include "qual_val_f.h"
#include "adap.h"
#include "entropy_f.h"
#include "bm_f.h"
#include "uthash.h"
#include "collapse_f.h"


#define chomp(x) (strtok(x,"\n"))
#define LEN 150
#define L 50

#define R  "\x1b[31m"
#define G  "\x1b[32m"
#define Y  "\x1b[33m"
#define B  "\x1b[34m"
#define M  "\x1b[35m"
#define C  "\x1b[36m"
#define E  "\x1b[0m"

#define BSIZE 1024*1024

char* clip_5p(char *str,int len);
int get_umi2(char *str, int ul,char *end,int window);
int nicenumber(long unsigned int);

hkey *ghash=NULL;


int main(int argc, char *argv[]){


	char infile[L];
	char outfile_f[50];
	char pref[L];
	char adap[]="TGGAATTCTCGGGTGCCAAGG";
	int adapl=8;
	int adapu=0;
	int trim=0;
	int clip5p=0;
	int ul=0;
	int entropyu=0;
	int qualu=0;
	int collapseu=0;
	int verbose=0;
	int min_len=0;

	int sstart;
	int clipp=-1;
	int slen;

	FILE *file=NULL;
	FILE *outfile=NULL; /*file pointer for the output file */ 
	FILE *rshort=NULL; /* file pointer for the reads that are too short*/
	FILE *cfile=NULL;  /* file pointer for the collapsed file */
	FILE *umicol=NULL;

	char umicol_f[50];
	char colfile[120];

	char rshort_f[50];

	char arr[LEN];
	char id[LEN];
	char oseq[LEN];
	char trimseq[LEN];

	char *seq;     /* file pointer pointing to current sequence, used throughout for clipping etc */
	char qual[LEN];
	char finals[LEN];

	unsigned int i;
	unsigned int fq=1;


	hkey *s2,*s3,*tmp2,*tmp3;/*make new structure pointers*/

	/* do you want to clip sequencing adapters */
	char *clip;
	int bmGs[LEN], bmBc[4];
	regex_t *regex;
	/* do you want to clip x number of nt from the beginning */
	/*char *c5pseq;*/

	/* do you want to get umis removed */
	char *umi;
	char umie[2]="CA";	/* we can adapt here but for us now umis have to have CA in the end	*/
	int umiu=0;
	int umip=0;
	FILE *fumi;
	char umifn[100];
	char umiret[20]; /* adjust here if umi is longer */

	/* do you want the entropy calculated for your final sequence */
	double entropy;

	/* do you want to get quality value stats */
	unsigned int line=0;
	unsigned long int sline=0;

	int sout=0;	

	int bytes_read;
	size_t len,back;
	char textbuf[BSIZE];
	char *p;
	char *pold;
	int first;

	if(argc < 5){
		fprintf(stderr,"\nUsage:\n" B "read_fastq" C " -f" E " readfile" C " -o" E " outfile [options]\n");
		fprintf(stderr,"\n  [options]\n");
		fprintf(stderr,"\t"G" -a"E" [char] -> ADAPTER \n");
		fprintf(stderr,"\t"G" -b"E" [int]  -> adap_length -> number of nucleotides to use from adapterseq\n");
		fprintf(stderr,"\t"G" -z"E"        -> use default adapter TGGAATTCTCGGGTGCCAAGG with length 8\n");
		fprintf(stderr,"\t              only default is used if option a is omitted\n");
		fprintf(stderr,"\t"G" -t"E" [char] -> trimchar -> if given then these chars will be trimmed from the end, \n");
		fprintf(stderr,"\t              if clip adap then these are trimmed after adapremoval \n");
		fprintf(stderr,"\t"G" -p"E" [int]  -> clip5p -> this needs to be the number of nt to be clipped in front\n");
		fprintf(stderr,"\t"G" -u"E" [int]  -> umis removal -> do you want UMIs in the beginning to be removed \n");
		fprintf(stderr,"\t"G" -e"E"        -> set to one if you want entropy to be calculated\n");
		fprintf(stderr,"\t"G" -q"E"        -> set to one if you want to get qual_val stats calculated	\n");
		fprintf(stderr,"\t"G" -c"E"        -> set to one if you want to get collapsed reads \n");
		fprintf(stderr,"\t"G" -m"E" [int]  -> set to min-length if you want to output only reads of this min_length\n");
		fprintf(stderr,"\t                   used only for collapsed files now\n");
		fprintf(stderr,"\t"G" -s"E"        -> print the processed input file to stdout instead of printing to outfile\n"); 
		fprintf(stderr,"\n");
		exit(0);
	}

	if(getopts(argc,argv,infile,pref,adap,&adapl,&trim,&clip5p,&ul,&entropyu,&qualu,&collapseu,&adapu,&min_len,&sout)){
		exit(0);
	}
	if(!pref[0])strcpy(pref,"default");

	strcpy(outfile_f,pref);
	strcat(outfile_f,"_clipped.fastq");



	fprintf(stderr,"testing getopt \n\
			infile = %s\n\
			pref       = %s\n\
			adapter    = %s\n\
			adap-len   = %d\n\
			adapterclip= %d\n\
			trimseq    = %c\n\
			clip5p     = %d\n\
			umilen     = %d\n\
			entropy    = %d\n\
			qualval    = %d\n\
			collapse   = %d\n\
			min_len    = %d\n\
			\n",infile,pref,adap,adapl,adapu,trim,clip5p,ul,entropyu,qualu,collapseu,min_len);


	if(adapu){
		/* init boyer moore and regex for search */
		regex=(regex_t *)malloc(adapl*sizeof(*regex));
		init_pattern(regex,adap,adapl,1);

		preBmGs(adap, adapl, bmGs);
		preBmBc(adap, adapl, bmBc);
		if(verbose) fprintf(stderr,"using adapter match %.*s\n",adapl,adap);
	}


	/* do you want to trim a specific nt from the end of the sequence */

	if(ul){
		strcpy(umifn,pref);
		strcat(umifn,"_umi.fastq");
		umiu=ul;

		if(!(fumi=fopen(umifn,"w"))){
			fprintf(stderr,"File for writing umis could not be opened\n");
			exit(0);
		}
	}




	/***************************************************************/
	/* now we open the file and parse it */


	/* now we open the file for reading or read from stdin */	

	if(sout){outfile=stdout;}else{
		if(!(outfile=fopen(outfile_f,"w"))){
			fprintf(stderr,"file %s - could not be opened \n",outfile_f);
			exit(0);	
		}
	}
	fprintf(stderr,"using read\n");
	if(!(file=fopen(infile,"r"))){
		if(infile[0] == '-'){
			file=stdin;
			if(verbose) fprintf(stderr,"reading from stdin\n");
		}else{
			if(verbose) fprintf(stderr,"file %s not found and stdin not given\n",infile);
			exit(0);
		}
	}

	first=1;
	memset(textbuf, 0, BSIZE);

	while((bytes_read=fread(textbuf,1,BSIZE,file))) {
		if (!bytes_read)
			break;
		pold=textbuf;
		first=1;
		for(p = textbuf; (p =memchr(p, '\n', (textbuf + bytes_read) - p)); ++p){
			line++;
			if(first){first=0;}else{pold++;}
			len=p-pold;
			/*strncpy(arr,pold,len);*/ /* this is our current line which we need to process now */
			memcpy(arr,pold,len);
			arr[len]='\0';

			if(line == 1 && (arr[0] == '>' ||arr[0] == '@')){
				for(i=0;i < strlen(arr);i++){
					if(arr[i] == ' ' || arr[i] == '\n'){ 
						arr[i]='\0';
						break;
					}
				}
				strcpy(id,arr);
			}else if(line==2 && (arr[0] == 'A' || arr[0] == 'C' || arr[0] == 'G' || arr[0] == 'T' || arr[0] == 'N' || arr[0] == 'U')){
				sline++;
				strcpy(oseq,arr);

				seq=oseq;
				slen=strlen(seq);

				/* clip adapter here*/
				if(adapu){
					/* use boyer more first, if fail use pattern match 	*/
					clip=BM(oseq,adap,18,adapl,slen,bmBc,bmGs);
					if(!clip){	
						if(verbose) fprintf(stderr,"using pattern match now\n");
						clipp=clip_adapter(oseq,adap,adapl,regex,verbose);
						if(clipp != -1){
							strncpy(arr,oseq,clipp);
							arr[clipp]='\0';
							clip=arr;
							/*seq+=clipp;*/
							;
						}
					}
					if(clip){
						seq=clip;
						/*	printf("%d %s\n",clipp,seq); */
					}
					if(verbose){ 
						fprintf(stderr,"%s\n",oseq);
						fprintf(stderr,"%s\n",seq);
					}
				}

				if(trim){
					strcpy(trimseq,seq);
					for(i=strlen(trimseq)-1;i>0;i--){
						if(trimseq[i] == trim){
							trimseq[i]='\0';
						}else{
							break;
						}
					}
					seq=trimseq;
					if(verbose) fprintf(stderr,"%s\n",seq);
				}

				if(clip5p){
					seq+=clip5p;/* that should be enough here */
					/*c5pseq=clip_5p(seq,clip5p);*/

					/*seq=c5pseq;*/
					if(verbose) fprintf(stderr,"%s\n",seq);
				}

				if(umiu){
					umip=get_umi2(seq,ul,umie,2);
					umi=seq+umip;
					if(umip){
						sprintf(umiret,"%.*s", umip,oseq);
						seq=umi;
					}else{
						memset(umiret,0,ul+4);
					}

					if(verbose) fprintf(stderr,"%s\n",seq);


					fprintf(fumi,"%s\n",id);
					fprintf(fumi,"%.*s\n", umip,oseq+clip5p);
				}
				sstart=strstr(oseq,seq)-oseq;
				slen=strlen(seq);


				if(entropyu){
					entropy=get_entropy(seq);
					if(verbose) fprintf(stderr,"%f\n",entropy);
				}

				if(collapseu){
					if(umiu && umip){
						add_seq2(seq,umiret,1LU,&ghash);
					}else{
						add_seq2(seq,"NOUMI",1LU,&ghash);
					}
				}
				strncpy(finals,seq,slen);
				finals[slen]='\0';
				fprintf(outfile,"%s",id);
				if(entropyu) printf("_H_%f",entropy);

				/*printf("%s\n",seq);*/

				if(fq == 0){ 
					line = 0;
					fprintf(outfile,"\n%s\n",seq);
				}

			}else if(line ==3){
			}else if(line == 4){

				strncpy(qual,arr+sstart,slen);
				qual[slen]='\0';
				if(qualu){
					get_qual(qual,res,33);
					fprintf(outfile,"_avQ_%.2f_lowQ_%.f",res[0],res[1]);
				}

				if(umiu){
					fprintf(fumi,"+\n%.*s\n",umip,arr+clip5p);
				}

				/*print qual val of file*/
				fprintf(outfile,"\n%s\n+\n%s\n",finals,qual);

				line=0;

			}else{
				continue;
			}
			pold=p;
		}
		pold++;
		back= textbuf+bytes_read-pold;
		fseek(file, -back, SEEK_CUR);
	}

	if(umiu){
		fclose(fumi);
	}

	if(collapseu){
		strcpy(colfile,pref);
		strcat(colfile,"_collapsed.fa");

		if(min_len){
			strcpy(rshort_f,pref);
			strcat(rshort_f,"_too_short_collapsed.fa");
			if(!(rshort=fopen(rshort_f,"w"))){
				fprintf(stderr,"Could not create file %s for writing collapsed reads which are too short\n",rshort_f);
				min_len=0;
			}
		}

		if(umiu){
			strcpy(umicol_f,pref);
			strcat(umicol_f,"_umi_collapsed.fa");
			if(!(umicol=fopen(umicol_f,"w"))){
				fprintf(stderr,"Could not create file %s for writing collapsed reads which are too short\n",umicol_f);
			}
		}	


		if((cfile=fopen(colfile,"w"))==NULL){
			fprintf(stderr,"Could not create file %s for writing collapsed reads\n",colfile);
			cfile=stdout;
		}
		print_entries(1,&ghash,cfile,umiu,rshort,min_len,umicol);
		if(cfile){ fclose(cfile);}
		if(rshort){ fclose(rshort);}
		if(umicol) fclose(umicol);

		/* free hash structure */
		HASH_ITER(hh, ghash, s2, tmp2) {
			HASH_ITER(hh, s2->ss, s3, tmp3) {
				HASH_DEL(s2->ss, s3);
				free(s3);
			}
			HASH_DEL(ghash, s2);
			free(s2);
		}

	}
	nicenumber(sline);
	fprintf(stderr," sequences processed\n");
	/*fprintf(stderr,"%lu sequences processed\n",sline); */
	if(adapu){
		for(i=0;i<adapl;i++){
			regfree(&regex[i]);
		}
		free(regex);
	}
	if(outfile) fclose(outfile);
	if(file) fclose(file);
	return 0;
}



char* clip_5p(char *str,int len){
	char *s;
	s=str+len;
	return s;
}


/*identify umi at beginning and then return clipped umi sequence */
int get_umi2(char *str, int ul,char *end,int window){
	int i;
	int slen=strlen(str);
	if(!slen) return 0;


	if(str[ul-2] == end[0] && str[ul-1] == end[1]){
		return ul;
	}else{
		for(i=ul-window;i<=ul+window;i++){
			if(str[i-2] == end[0] && str[i-1] == end[1]){
				return i;
			}
		}
	}
	return 0;
}

int nicenumber(long unsigned int x){
	char nn[100];
	int k=0;
	int offset=0;
	int i;
	sprintf(nn, "%lu", x);
	offset=strlen(nn)%3;
	k=3-offset;
	for(i=0;i<strlen(nn);i++){
		if(k % 3 == 0 && i){
			fprintf(stderr,".");
		}
		fprintf(stderr,"%c",nn[i]);
		k++;
	}
	return 0;
}




