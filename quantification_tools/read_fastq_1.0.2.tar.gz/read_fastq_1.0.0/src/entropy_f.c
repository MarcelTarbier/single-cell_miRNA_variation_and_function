#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#define COL 5
#define log2(x) (log(x)/log(2))

double get_entropy(char *str){
	int i,j;
	int len;
	/*create matrix dynamically*/
	long int matrix[COL];
			
	/*  long unsigned int seq = 0;*/
	double h,p;
	len=strlen(str);	
	h= 0;

	if(str[0] == '\n' ){
		return -1;
	}

	/*	  check for Ns and skip if necessary*/
	for(i=0;i<COL;i++){
		matrix[i]=0;
	}
	for(j=0; j< len;j++){
		if(str[j] == 'A'|| str[j] == 'a'){ matrix[0]++;}  
		else if(str[j] == 'C' || str[j] == 'c'){ matrix[1]++;}
		else if(str[j] == 'G' || str[j] == 'g'){ matrix[2]++;}
		else if(str[j] == 'T' || str[j] == 't'){ matrix[3]++;}
		else if(str[j] == 'N' || str[j] == 'n'){ matrix[4]++;} 

		else{
			break;
		}
	}

	for(i=0;i<COL;i++){
		p =(double)matrix[i]/len;
		if(!p) p=1;
		h += -(p*log2(p));
	}
	return h;
}
