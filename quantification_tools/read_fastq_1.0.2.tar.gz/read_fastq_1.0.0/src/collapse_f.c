#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "uthash.h"
#define chomp(x) (strtok(x,"\n"))

#include "collapse_f.h"

/* declare the structure that should be hashed */

hkey *find_seq(char *id,hkey *hash){
	hkey *s;
	HASH_FIND_STR(hash,id,s);
	return s;
}

int v_sort(hkey *a, hkey *b) {
	return (b->mult - a->mult);
}
int v_sort_u(hkey *a, hkey *b){
	return (b->umis - a->umis);
}


int add_seq(char *fseq, unsigned long int fmult, hkey *hash) {
	hkey *s;/*make new structure*/
	s = malloc(sizeof(hkey)); /* allocate space for it*/
	strcpy(s->seq, fseq);
	s->mult=fmult;
	s->ss=NULL; /* init sub hash key if one is there */
	HASH_ADD_STR(hash, seq, s ); /* id: name of key field */
	return 0;
}

int addtest(char *fseq,int fmult,hkey *hash){
	hkey *s;/*make new structure*/
	s = malloc(sizeof(*s)); /* allocate space for it*/
	strcpy(s->seq, fseq);
	s->mult=fmult;
	s->ss= NULL;
	HASH_ADD_STR(hash,seq, s ); /* id: name of key field */


	return 0;
}

int add_seq2(char *fseq,char *useq, unsigned long int fmult,hkey **ghash){
	hkey *seqs;/*=malloc(sizeof(*seqs));*/
	hkey *s;
	hkey *i;
	hkey *subseq;
	seqs=find_seq(fseq,*ghash);

	if(!seqs){	
		/* fprintf("make new structure %s\n",fseq); */
		s =(hkey *)malloc(sizeof(hkey)); /* allocate space for it*/
		strcpy(s->seq, fseq);
		s->mult=fmult;
		s->ss= NULL;
		s->umis=1;
		HASH_ADD_STR(*ghash, seq, s ); /* id: name of key field */

		i = (hkey *) malloc(sizeof(hkey)); /* allocate space for it*/
		strcpy(i->seq, useq);
		i->mult=fmult;
		i->ss= NULL;
		HASH_ADD_STR(s->ss, seq,i );
	}else{
		seqs->mult++;
		/* now check if umi is already in */
		if(!(subseq=find_seq(useq,seqs->ss))){/* umi is not in so */
			add_seq(useq,fmult,seqs->ss);
			seqs->umis++;
		}else{
			subseq->mult++;
		}
	}
	return 0;
}



int print_entries(int fasta,hkey **ghash,FILE *outfile,int umiu,FILE *rshort,int min_len, FILE *umicol){
	hkey *s, *u;
	int count=0;
	FILE *file=outfile;
	char qual[]="BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";


	if(!umiu){
		HASH_SORT(*ghash, v_sort);
	}else{
		HASH_SORT(*ghash, v_sort_u);
	}
	for(s=*ghash;s!=NULL;s=s->hh.next){
		count++;
		file=outfile; /* set file pointer here */
		if(min_len && strlen(s->seq) < min_len) file=rshort; /* reset file pointer here*/


		if(fasta){
			fprintf(file,">");
			if(umiu)fprintf(umicol,">");
		}else{
			fprintf(file,"@");
			if(umiu) fprintf(umicol,"@");
		}

		/* here we adapt the outfile count routine */
		/* if umis are used then we get the number of umis first and then the number of reads */
		if(umiu){
			fprintf(file,"seq_%d_x%lu_u%lu\n%s\n",count,s->umis,s->mult,s->seq);
			fprintf(umicol,"seq_%d_x%lu_u%lu\n",count,s->umis,s->mult);
			/* for the umi seqs we now print the umis like UMI-seq\tnums\n"; */
			HASH_SORT(s->ss, v_sort);
			for(u=s->ss;u!=NULL;u=u->hh.next){
				fprintf(umicol,"%s\t%lu\n",u->seq,u->mult);
			}





		}else{/* this was easy */
			fprintf(file,"seq_%d_x%lu\n%s\n",count,s->mult,s->seq);
		}

		if(fasta){}else{
			fprintf(file,"+\n");
			fprintf(file,"%.*s\n",(int)strlen(s->seq),qual);
		}
	}
	return 0;
}
