#include <regex.h>

int init_pattern(regex_t *regex,char *adap, int adapl,int mm);
int init_regex_obj(regex_t *regex,char *adap,int adapl);
int clip_adapter(char *seq, char *adap,int adapl,regex_t *regex,int verbose);

