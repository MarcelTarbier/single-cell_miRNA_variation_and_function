
extern double res[];

int get_qual(char *quals, double *res,int t);
