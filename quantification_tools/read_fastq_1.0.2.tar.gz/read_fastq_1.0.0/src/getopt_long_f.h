int getopts(int argc,char *argv[],char *infile,char *pref,char *adap,int *adapl,int *trim,int *clip5p,int *ul,int *entropyu,int *qualu,int *collapseu,int *adapu,int *min_len,int *sout);
