#define _GNU_SOURCE 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ASIZE 4
#define XSIZE 150
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

int get_num(char c){
	if(c == 'A' || c == 'a') return 0;
	if(c == 'C' || c == 'c') return 1;
	if(c == 'G' || c == 'g') return 2;
	if(c == 'T' || c == 't') return 3;
	if(c == 'N' || c == 'n') return 4;
	return -1;
}



void preBmBc(char *x, int m, int bmBc[]) {
	int i;
	for (i = 0; i < ASIZE; i++)
		bmBc[i] = m;
	for (i = 0; i < m - 1; i++)
		bmBc[get_num(x[i])] = m - i - 1;
}


void suffixes(char *x, int m, int *suff) {
	int f, g, i;

	suff[m - 1] = m;
	g = m - 1;
	for (i = m - 2; i >= 0; --i) {
		if (i > g && suff[i + m - 1 - f] < i - g)
			suff[i] = suff[i + m - 1 - f];
		else {
			if (i < g)
				g = i;
			f = i;
			while (g >= 0 && x[g] == x[g + m - 1 - f])
				--g;
			suff[i] = f - g;
		}
	}
}

void preBmGs(char *x, int m, int bmGs[]) {
	int i, j, suff[XSIZE];

	suffixes(x, m, suff);

	for (i = 0; i < m; ++i)
		bmGs[i] = m;
	j = 0;
	for (i = m - 1; i >= 0; --i)
		if (suff[i] == i + 1)
			for (; j < m - 1 - i; ++j)
				if (bmGs[j] == m)
					bmGs[j] = m - 1 - i;
	for (i = 0; i <= m - 2; ++i)
		bmGs[m - 1 - suff[i]] = m - 1 - i;
}





char *BM(char *db, char *pattern,int j, int patternlen,int dblen,int *bmBc,int* bmGs){
	int i,found;	
	found=-1;	
	while (j <= dblen - patternlen) {
		for (i = patternlen - 1; i >= 0;i--){
			if(pattern[i] != db[i + j]){
				break;
			}
		}
		if (i < 0) {
			found=j;
			j += bmGs[0];
		}else{
			j += MAX(bmGs[i], bmBc[get_num(db[i + j])] - patternlen + 1 + i);
		}
	}	
		
	if(found == -1){
		return NULL;
	}else{
		return strndup(db, found);
		
	}
	/*printf("%.*s", found, db);*/
}




