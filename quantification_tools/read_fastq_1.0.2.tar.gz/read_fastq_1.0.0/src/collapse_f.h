typedef struct hkey_t{
	char seq[200]; /* that is our key */
	struct hkey_t *ss;
	unsigned long int mult; /* that is our value*/
	unsigned long int umis;
	float entropy; /* save entropy here if desired */
	float qualv;    /* save quality values her eif desired */

	UT_hash_handle hh; /* hash handle */
} hkey;


int add_seq2(char *fseq,char *useq, unsigned long int fmult,hkey **ghash);
int print_entries(int fasta,hkey **ghash,FILE *outfile,int umiu,FILE *rshort,int min_len,FILE *umicol);
