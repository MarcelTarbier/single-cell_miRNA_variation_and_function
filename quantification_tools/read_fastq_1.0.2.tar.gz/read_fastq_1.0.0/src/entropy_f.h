double get_entropy(char *str);
