#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include <string.h>
#include "adap.h"


int init_pattern(regex_t *regex,char *adap, int adapl, int mm){
	/*char *suffix=(char *)malloc(strlen(adap)*sizeof(char));*/
	/*char *prefix=(char *)malloc(strlen(adap)*sizeof(char));*/
	int reti;

	/* Compile regular expression */
	int j;
	for(j=0;j<adapl;j++){	
		char *suffix=(char *)malloc(40*sizeof(char));
		char *prefix=(char *)malloc(40*sizeof(char));
		if(!mm){
			strncpy(prefix,adap,j+1);
			prefix[j+1]='\0';
		}else{
			strncpy(prefix,adap,j);
			prefix[j]='\0';
		}

		strncpy(suffix,adap+j+1,adapl-j-1);
		suffix[adapl-j-1]='\0';
		if(!mm){
			strcat(prefix,"\\{0,1\\}");
		}else{
			strcat(prefix,"[ACGT]\\{0,1\\}");
		}
		strcat(prefix,suffix);
/*		printf("%d %s\n",j,prefix);*/

		reti = regcomp(&regex[j], prefix, 0);
		if (reti) {
			fprintf(stderr, "Could not compile regex %d  %d\n",j,adapl);
			exit(1);
		}
	
		free(prefix);
		free(suffix);
	}
	return 0;
}


int clip_adapter(char *seq, char *adap,int adapl,regex_t *regex,int verbose){
	/* init regex object*/
	
			int i,j,found;
	int reti;
	char msgbuf[100];
	regmatch_t pmatch[10];	
	/* check here if pattern is matching or not*/
	reti = regexec(&regex[0], seq, 10, pmatch, 0);
	if (!reti) {
		if(verbose) fprintf(stderr,"Match at pos %d\n",(unsigned int)pmatch[0].rm_so);
		if(verbose){
			if(verbose) fprintf(stderr,"%s\n",seq);
			i=0;
			while(i<pmatch[0].rm_so){
				if(verbose) fprintf(stderr," ");
				i++;
			}
			if(verbose) fprintf(stderr,"%s\n",adap);
			if(verbose) fprintf(stderr,"%s\n",strndup(seq,pmatch[0].rm_so));

		}
		return pmatch[0].rm_so;
	}else if (reti == REG_NOMATCH) {
	j=0;
	found=0;
		while((reti != 0) & (j < (adapl-1)) ){
			j++;
			reti = regexec(&regex[j], seq, 10, pmatch, 0);
			if (reti == REG_NOMATCH){
				if(verbose) fprintf(stderr,"no match for pattern %i\n",j+1);
			}else if(!reti){
				if(verbose) fprintf(stderr,"match found for pattern %i at position %d\n",j+1,(int)pmatch[0].rm_so);
				if(verbose){
					fprintf(stderr,"%s\n",seq);
					i=0;
					while(i<pmatch[0].rm_so){
						fprintf(stderr," ");
						i++;
					}
					fprintf(stderr,"%s\n",adap);
					fprintf(stderr,"%s\n",strndup(seq,pmatch[0].rm_so));

				}
				found=1;
				return pmatch[0].rm_so;
			}else{
				regerror(reti, &regex[j], msgbuf, sizeof(msgbuf));
				if(verbose) fprintf(stderr, "Regex match failed: %s\n", msgbuf);
				exit(1);
			}
		}
		if(!found){
			if(j == adapl-1){if(verbose) fprintf(stderr,"no match found at all\n");}
		}
	} else {
		if(verbose) fprintf(stderr,"no match found\n");
	}

	return -1;
}


